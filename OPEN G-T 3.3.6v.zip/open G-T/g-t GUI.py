import sys
import tkinter as tk
import customtkinter as ctk
from tkinter import messagebox, simpledialog
from pathlib import Path
import ollama
import threading
import shutil
import time
from itertools import cycle

# ====================== CONFIG ======================
ctk.set_appearance_mode("Dark")
ctk.set_default_color_theme("blue")

BASE_DIR = Path(__file__).parent
CHAT_DATA_DIR = BASE_DIR / "chat data"
PERSONA_DIR = BASE_DIR / "storing data for a shift"

# Подготовка папок
CHAT_DATA_DIR.mkdir(parents=True, exist_ok=True)
PERSONA_DIR.mkdir(parents=True, exist_ok=True)

MODEL = "deepseek-v3.1:671b-cloud"

class AnimatedButton(ctk.CTkButton):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.animation_running = False
        self.original_text = self.cget("text")
        
    def start_loading_animation(self, text="Генерация"):
        self.animation_running = True
        self.configure(state="disabled")
        self._animate_loading(text)
    
    def _animate_loading(self, text, dots=0):
        if not self.animation_running:
            return
        dots = (dots % 4)
        self.configure(text=f"{text}{'.' * dots}")
        self.after(500, lambda: self._animate_loading(text, dots + 1))
    
    def stop_loading_animation(self):
        self.animation_running = False
        self.configure(state="normal", text=self.original_text)

class StatusPopup(ctk.CTkToplevel):
    def __init__(self, parent, title, message):
        super().__init__(parent)
        self.title(title)
        self.geometry("500x300")
        self.resizable(False, False)
        
        # Центрируем окно
        self.transient(parent)
        self.grab_set()
        
        # Фрейм для контента
        self.frame = ctk.CTkFrame(self, fg_color="transparent")
        self.frame.pack(fill="both", expand=True, padx=20, pady=20)
        
        # Анимированная иконка
        self.icon_label = ctk.CTkLabel(self.frame, text="🤖", font=("Arial", 48))
        self.icon_label.pack(pady=(0, 10))
        
        # Статус текст
        self.status_label = ctk.CTkLabel(self.frame, text=message, font=("Arial", 14, "bold"))
        self.status_label.pack(pady=(0, 20))
        
        # Прогресс бар
        self.progress = ctk.CTkProgressBar(self.frame, width=400)
        self.progress.pack(pady=10)
        self.progress.set(0)
        
        # Детальный лог
        self.log_text = ctk.CTkTextbox(self.frame, height=100, font=("Consolas", 11))
        self.log_text.pack(fill="both", expand=True, pady=(10, 0))
        
        self.animation_index = 0
        self.animate_icon()
    
    def animate_icon(self):
        icons = ["🤖", "⚙️", "💭", "✨", "🎭", "🧠"]
        self.animation_index = (self.animation_index + 1) % len(icons)
        self.icon_label.configure(text=icons[self.animation_index])
        self.after(300, self.animate_icon)
    
    def update_status(self, message, progress=None):
        self.status_label.configure(text=message)
        if progress is not None:
            self.progress.set(progress)
    
    def add_log(self, text):
        self.log_text.insert("end", f"• {text}\n")
        self.log_text.see("end")
        self.update()
    
    def close(self):
        self.destroy()

class GTApp(ctk.CTk):
    def __init__(self):
        super().__init__()
        self.title("open G-T | Trinity Console v3.3")
        self.geometry("1400x900")
        
        self.grid_columnconfigure(1, weight=1)
        self.grid_rowconfigure(0, weight=1)
        
        self.active_chat_path = None
        self.thinking_animation = None
        self.build_ui()
        self.refresh_all_lists()

    def build_ui(self):
        # --- ЛЕВАЯ ПАНЕЛЬ (САЙДБАР) ---
        self.sidebar = ctk.CTkFrame(self, width=350, corner_radius=0)
        self.sidebar.grid(row=0, column=0, sticky="nsew")
        
        ctk.CTkLabel(self.sidebar, text="G-T TRINITY CORE", font=("Arial", 22, "bold")).pack(pady=20)

        # --- 3 КНОПКИ СОЗДАНИЯ ---
        self.btn_chat = AnimatedButton(self.sidebar, text="+ НОВЫЙ ЧАТ", fg_color="#27ae60", command=self.ui_new_chat)
        self.btn_chat.pack(padx=20, pady=5, fill="x")

        self.btn_bot = AnimatedButton(self.sidebar, text="🤖 СДЕЛАТЬ ПЕРСОНУ ИИ", fg_color="#8e44ad", command=lambda: self.ui_generate("bot"))
        self.btn_bot.pack(padx=20, pady=5, fill="x")

        self.btn_me = AnimatedButton(self.sidebar, text="👤 СДЕЛАТЬ СЕБЕ ПЕРСОНУ", fg_color="#2980b9", command=lambda: self.ui_generate("user"))
        self.btn_me.pack(padx=20, pady=5, fill="x")

        # --- 3 КНОПКИ (ТАБА) ВЫБОРА ---
        self.tabs = ctk.CTkTabview(self.sidebar)
        self.tabs.pack(fill="both", expand=True, padx=10, pady=10)
        self.tab_chat = self.tabs.add("Чаты")
        self.tab_bots = self.tabs.add("Боты")
        self.tab_me = self.tabs.add("Я (Профили)")

        self.scroll_chat = ctk.CTkScrollableFrame(self.tab_chat, fg_color="transparent")
        self.scroll_chat.pack(fill="both", expand=True)

        self.scroll_bots = ctk.CTkScrollableFrame(self.tab_bots, fg_color="transparent")
        self.scroll_bots.pack(fill="both", expand=True)

        self.scroll_me = ctk.CTkScrollableFrame(self.tab_me, fg_color="transparent")
        self.scroll_me.pack(fill="both", expand=True)

        # --- ОБЛАСТЬ ЧАТА ---
        self.main_view = ctk.CTkFrame(self, fg_color="transparent")
        self.main_view.grid(row=0, column=1, sticky="nsew", padx=20, pady=20)
        self.main_view.grid_rowconfigure(0, weight=1)
        self.main_view.grid_columnconfigure(0, weight=1)

        self.display = ctk.CTkTextbox(self.main_view, font=("Segoe UI", 16), state="disabled", wrap="word")
        self.display.grid(row=0, column=0, sticky="nsew", pady=(0, 15))

        self.input_area = ctk.CTkFrame(self.main_view, fg_color="transparent")
        self.input_area.grid(row=1, column=0, sticky="ew")
        self.input_area.grid_columnconfigure(0, weight=1)

        self.entry = ctk.CTkEntry(self.input_area, placeholder_text="Выберите чат и настройте мир...", height=55)
        self.entry.grid(row=0, column=0, sticky="ew", padx=(0, 10))
        self.entry.bind("<Return>", lambda e: self.send_message())

        self.send_btn = ctk.CTkButton(self.input_area, text="ОТПРАВИТЬ", width=120, height=55, command=self.send_message)
        self.send_btn.grid(row=0, column=1)

    def start_thinking_animation(self):
        """Запускает анимацию мышления в поле ввода"""
        self.thinking_animation = True
        self.animate_thinking()
    
    def animate_thinking(self, dots=0):
        if not self.thinking_animation:
            return
        if not self.entry.winfo_exists():  # Проверяем, существует ли виджет
            return
        dots = (dots % 4)
        self.entry.configure(placeholder_text=f"ИИ думает{'.' * dots}")
        self.entry.configure(state="disabled")
        self.after(500, lambda: self.animate_thinking(dots + 1))
    
    def stop_thinking_animation(self):
        self.thinking_animation = False
        if self.entry.winfo_exists():
            self.entry.configure(state="normal", placeholder_text="Пишите сообщение...")

    def add_message_with_animation(self, sender, message):
        """Добавляет сообщение с анимацией"""
        self.display.configure(state="normal")
        
        # Добавляем аватар
        avatar = "🤖" if sender == "Бот" else "👤"
        self.display.insert("end", f"\n{avatar} {sender}: ", ("sender",))
        
        # Анимируем появление текста
        for char in message:
            self.display.insert("end", char)
            self.display.see("end")
            self.update()
            time.sleep(0.01)  # Небольшая задержка для эффекта печати
        
        self.display.insert("end", "\n\n")
        self.display.configure(state="disabled")
        self.display.see("end")

    def add_log(self, text):
        """Добавляет текст в чат без анимации"""
        self.display.configure(state="normal")
        self.display.insert("end", text + "\n")
        self.display.configure(state="disabled")
        self.display.see("end")

    def refresh_all_lists(self):
        for s in [self.scroll_chat, self.scroll_bots, self.scroll_me]:
            for w in s.winfo_children(): w.destroy()

        # Список Чатов
        for f in sorted(CHAT_DATA_DIR.iterdir()):
            if f.is_dir():
                ctk.CTkButton(self.scroll_chat, text=f"💬 {f.name}", fg_color="transparent", anchor="w",
                              command=lambda p=f: self.load_chat(p)).pack(fill="x")

        # Библиотека (Боты и Я)
        for f in sorted(PERSONA_DIR.iterdir()):
            if f.is_dir():
                if (f / "start promt (required for proper operation).txt").exists():
                    ctk.CTkButton(self.scroll_bots, text=f"🤖 {f.name}", fg_color="transparent", anchor="w",
                                  command=lambda p=f: self.apply_to_chat(p)).pack(fill="x")
                elif (f / "!About you! (required for correct operation).txt").exists():
                    ctk.CTkButton(self.scroll_me, text=f"👤 {f.name}", fg_color="transparent", anchor="w",
                                  command=lambda p=f: self.apply_to_chat(p)).pack(fill="x")

    def ui_new_chat(self):
        name = simpledialog.askstring("Чат", "Название чата:")
        if name:
            p = CHAT_DATA_DIR / name
            p.mkdir(parents=True, exist_ok=True)
            (p / "chat history (do not touch).txt").write_text("", encoding="utf-8")
            self.refresh_all_lists()
            self.load_chat(p)

    def ui_generate(self, mode):
        idea = simpledialog.askstring("ИИ Конструктор", f"Опишите личность ({mode}):")
        if not idea: return
        
        # Блокируем кнопки
        self.btn_bot.start_loading_animation("Генерация персонажа")
        self.btn_me.start_loading_animation()
        
        # Создаем попап со статусом
        popup = StatusPopup(self, "Генерация персонажа", f"Создание {mode} персонажа...")
        
        def task():
            try:
                target = "AI Agent" if mode == "bot" else "User/Player profile"
                
                # Шаг 1
                popup.update_status("Анализ запроса...", 0.1)
                popup.add_log("🎯 Анализирую описание личности...")
                time.sleep(0.5)
                
                # Шаг 2
                popup.update_status("Генерация характера...", 0.3)
                popup.add_log(f"📝 Создаю детальную личность для: {target}")
                time.sleep(0.3)
                
                # Шаг 3
                popup.update_status("Формирование ответа ИИ...", 0.6)
                popup.add_log("🧠 Запрос к нейросети...")
                
                prompt = f"Create a detailed persona for {target} based on: {idea}. If idea is in Russian, ensure the prompt forces Russian communication."
                resp = ollama.chat(model=MODEL, messages=[{"role": "user", "content": prompt}])
                content = resp['message']['content']
                
                # Шаг 4
                popup.update_status("Сохранение персонажа...", 0.8)
                popup.add_log("💾 Сохраняю персонажа в библиотеку...")
                
                folder = PERSONA_DIR / f"{mode}_{idea[:10].strip()}"
                folder.mkdir(parents=True, exist_ok=True)
                
                fname = "start promt (required for proper operation).txt" if mode == "bot" else "!About you! (required for correct operation).txt"
                (folder / fname).write_text(content, encoding="utf-8")
                
                # Шаг 5
                popup.update_status("Готово!", 1.0)
                popup.add_log("✅ Персонаж успешно создан!")
                popup.add_log(f"📁 Сохранено в: {folder.name}")
                
                time.sleep(1)
                
                self.after(0, self.refresh_all_lists)
                self.after(0, lambda: messagebox.showinfo("Готово", "Персонаж сохранен в библиотеку!"))
                
            except Exception as e:
                popup.add_log(f"❌ Ошибка: {str(e)}")
                time.sleep(1)
            finally:
                self.after(0, popup.close)
                self.after(0, lambda: self.btn_bot.stop_loading_animation())
                self.after(0, lambda: self.btn_me.stop_loading_animation())

        threading.Thread(target=task, daemon=True).start()

    def apply_to_chat(self, folder):
        if not self.active_chat_path:
            messagebox.showwarning("!", "Сначала выберите чат в списке!")
            return
        
        # Анимация применения
        popup = StatusPopup(self, "Применение персонажа", f"Загрузка {folder.name}...")
        
        def apply():
            for f in ["start promt (required for proper operation).txt", "!About you! (required for correct operation).txt"]:
                if (folder / f).exists():
                    shutil.copy2(folder / f, self.active_chat_path / f)
                    popup.add_log(f"✅ Скопирован: {f}")
                time.sleep(0.3)
            popup.add_log("✨ Персонаж успешно применен к чату!")
            time.sleep(1)
            self.after(0, popup.close)
            self.after(0, lambda: messagebox.showinfo("Система", f"Профиль '{folder.name}' применен к чату."))
        
        threading.Thread(target=apply, daemon=True).start()

    def load_chat(self, path):
        self.active_chat_path = path
        hist_file = path / "chat history (do not touch).txt"
        hist = hist_file.read_text(encoding="utf-8") if hist_file.exists() else ""
        self.display.configure(state="normal")
        self.display.delete("1.0", "end")
        
        # Анимированная загрузка чата
        self.display.insert("end", f"📂 ЗАГРУЖЕНО: {path.name}\n", ("header",))
        self.display.insert("end", "═" * 50 + "\n\n")
        
        if hist:
            self.display.insert("end", hist)
        else:
            self.display.insert("end", "✨ Чат пуст. Начните диалог!\n")
        
        self.display.configure(state="disabled")
        self.display.see("end")

    def send_message(self):
        if not self.active_chat_path:
            messagebox.showwarning("!", "Сначала выберите чат!")
            return
        text = self.entry.get().strip()
        if not text:
            return
        
        self.entry.delete(0, tk.END)
        self.add_message_with_animation("Вы", text)
        
        # Блокируем отправку и поле ввода
        self.send_btn.configure(state="disabled")
        self.start_thinking_animation()

        threading.Thread(target=self.ai_logic, args=(text,), daemon=True).start()

    def ai_logic(self, user_text):
        try:
            p = self.active_chat_path
            bot_sys = (p / "start promt (required for proper operation).txt").read_text(encoding="utf-8") if (p / "start promt (required for proper operation).txt").exists() else "Narrator."
            me_sys = (p / "!About you! (required for correct operation).txt").read_text(encoding="utf-8") if (p / "!About you! (required for correct operation).txt").exists() else "User."
            history = (p / "chat history (do not touch).txt").read_text(encoding="utf-8") if (p / "chat history (do not touch).txt").exists() else ""

            system = f"BOT ROLE: {bot_sys}\n\nUSER PROFILE: {me_sys}\n\nStrictly follow the language of the personas."
            
            resp = ollama.chat(model=MODEL, messages=[
                {"role": "system", "content": system},
                {"role": "user", "content": f"HISTORY:\n{history}\n\nUSER SAYS: {user_text}"}
            ])
            ans = resp['message']['content']

            with open(p / "chat history (do not touch).txt", "a", encoding="utf-8") as f:
                f.write(f"Вы: {user_text}\nБот: {ans}\n\n")

            self.after(0, lambda: self.add_message_with_animation("Бот", ans))
        except Exception as e:
            self.after(0, lambda: self.add_log(f"❌ Ошибка: {e}"))
        finally:
            # ВАЖНО: РАЗБЛОКИРОВКА ВСЕГО, ЧТО БЫЛО ЗАБЛОКИРОВАНО
            self.after(0, self.stop_thinking_animation)
            self.after(0, lambda: self.send_btn.configure(state="normal"))

if __name__ == "__main__":
    app = GTApp()
    app.mainloop()