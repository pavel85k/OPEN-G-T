import sys
import time
from pathlib import Path
import ollama
import traceback

# ====================== CONFIGURATION ======================
BASE_DIR = Path(__file__).parent 
CONFIG_DIR = BASE_DIR / "ai config"
HISTORY_FILE = CONFIG_DIR / "chat history (do not touch).txt"

AI_NAME = "g-tBOT"
USER_NAME = "g-tPLAY"
MODEL = "deepseek-v3.1:671b-cloud"

# =========================================================

def freeze_on_error(error_msg: str):
    print("\n" + "!" * 60)
    print("CRITICAL ERROR OCCURRED:")
    print(error_msg)
    print("!" * 60)
    print(f"\nПуть скрипта: {Path(__file__).absolute()}")
    input("\n[ЗАМОРОЖЕНО] Нажмите ENTER для выхода...")
    sys.exit(1)

def load_config(filename: str) -> str:
    file_path = CONFIG_DIR / filename
    if not file_path.exists():
        file_path = CONFIG_DIR / f"{filename}.txt"

    if file_path.exists():
        try:
            return file_path.read_text(encoding="utf-8").strip()
        except Exception as e:
            print(f"⚠️ Ошибка чтения {filename}: {e}")
    return ""

def build_system_prompt() -> str:
    """Собирает все инструкции в один блок для роли 'system'"""
    start_prompt = load_config("start promt (required for proper operation)")
    user_info = load_config("!About you! (required for correct operation)")
    behavior = load_config("behavior (optional)")
    correcting = load_config("correcting AI errors")

    # Формируем четкую структуру для системы
    system_parts = []
    
    if start_prompt:
        system_parts.append(f"CORE INSTRUCTIONS:\n{start_prompt}")
    
    if user_info:
        system_parts.append(f"TARGET USER PROFILE:\n{user_info}")
        
    if behavior:
        system_parts.append(f"BEHAVIOR RULES:\n{behavior}")
        
    if correcting:
        system_parts.append(f"CORRECTION NOTES:\n{correcting}")

    # Если файлов нет, даем базовую роль
    final_prompt = "\n\n===\n\n".join(system_parts) if system_parts else "You are a helpful assistant."
    
    # Жесткое ограничение на формат ответа
    final_prompt += (
        "\n\nCRITICAL: Respond ONLY with message content. "
        f"Do not use prefixes like '{AI_NAME}:' or '{USER_NAME}:'."
    )
    return final_prompt

def parse_history_to_messages(history_lines: list[str], system_prompt: str) -> list[dict]:
    # Первым делом отправляем системные инструкции
    messages = [{"role": "system", "content": system_prompt}]
    
    for line in history_lines:
        line = line.strip()
        if ": " in line:
            parts = line.split(": ", 1)
            if len(parts) < 2: continue
            prefix, content = parts
            
            # Распределяем роли
            if prefix == AI_NAME:
                messages.append({"role": "assistant", "content": content})
            elif prefix == USER_NAME:
                messages.append({"role": "user", "content": content})
                
    return messages

def get_ai_response(messages: list[dict], retries=3) -> str:
    for attempt in range(retries):
        try:
            # Отправка структурированного списка (system, user, assistant...)
            response = ollama.chat(model=MODEL, messages=messages)
            return response['message']['content'].strip()
        except Exception as e:
            print(f"⚠️ Ошибка Ollama (попытка {attempt+1}): {e}")
            if attempt < retries - 1:
                time.sleep(2)
    return "❌ Ошибка: Не удалось получить ответ."

def main():
    if not CONFIG_DIR.exists():
        freeze_on_error(f"Папка 'ai config' не найдена в {BASE_DIR}")

    if not HISTORY_FILE.exists():
        HISTORY_FILE.touch()

    # Генерируем промпт один раз при запуске
    system_prompt = build_system_prompt()

    print(f"🚀 {AI_NAME} успешно запущен.")
    print(f"🤖 Используется модель: {MODEL}")
    print("-" * 30)

    while True:
        try:
            user_input = input(f"{USER_NAME}: ").strip()
            if not user_input:
                continue

            # Загружаем историю из файла
            history_lines = HISTORY_FILE.read_text(encoding="utf-8").splitlines()
            
            # Формируем пакет сообщений: [System, User, Assistant, User, Assistant, User (текущий)]
            messages = parse_history_to_messages(history_lines, system_prompt)
            messages.append({"role": "user", "content": user_input})

            # Отправляем весь контекст модели
            response_text = get_ai_response(messages)
            print(f"{AI_NAME}: {response_text}")

            # Записываем новый этап диалога в файл
            with open(HISTORY_FILE, "a", encoding="utf-8") as f:
                f.write(f"{USER_NAME}: {user_input}\n")
                f.write(f"{AI_NAME}: {response_text}\n")

        except KeyboardInterrupt:
            print("\n👋 Работа завершена.")
            break
        except Exception:
            freeze_on_error(traceback.format_exc())

if __name__ == "__main__":
    try:
        main()
    except Exception:
        freeze_on_error(traceback.format_exc())