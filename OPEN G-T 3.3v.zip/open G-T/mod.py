import os
import shutil
import tkinter as tk
from tkinter import messagebox
from pathlib import Path

# --- НАСТРОЙКИ ПУТЕЙ ---
BASE_DIR = Path(__file__).parent
MODS_DIR = BASE_DIR / "mods"

# Соответствие: имя файла в mods -> имя оригинального файла в проекте
MOD_MAP = {
    "gui": "g-t GUI.py",
    "creator": "creator.py",
    "chat": "chat.py",
    "manager": "manager.py",
    "suport": "suport.py"
}

class ModLauncher:
    def __init__(self):
        self.root = tk.Tk()
        self.root.withdraw()
        self.run()

    def run(self):
        # 1. Проверка или создание папки mods
        if not MODS_DIR.exists():
            if messagebox.askyesno("Modding System", "Папка 'mods' не найдена. Создать её?"):
                MODS_DIR.mkdir(parents=True, exist_ok=True)
                self.create_templates()
                messagebox.showinfo("Готово", "Папка 'mods' создана. Положите туда файлы .txt для замены кода.")
            return

        # 2. Поиск и применение модов
        self.apply_patches()

    def create_templates(self):
        """Создает пустые файлы-подсказки в папке mods"""
        for key in MOD_MAP.keys():
            temp_file = MODS_DIR / f"{key} mod.txt"
            if not temp_file.exists():
                temp_file.write_text(f"# Вставьте сюда измененный код для {MOD_MAP[key]}\n# После запуска этого скрипта, код в оригинале будет заменен.", encoding="utf-8")

    def apply_patches(self):
        """Сканирует папку mods и обновляет оригинальные скрипты"""
        found_mods = []
        
        # Проходим по всем файлам в папке mods
        for mod_file in MODS_DIR.glob("*.txt"):
            content = mod_file.read_text(encoding="utf-8").strip()
            
            # Если файл не пустой и это не просто шаблон
            if content and not content.startswith("# Вставьте сюда"):
                filename_lower = mod_file.name.lower()
                
                # Ищем, какому скрипту принадлежит мод
                for key, original_name in MOD_MAP.items():
                    if key in filename_lower:
                        target_path = BASE_DIR / original_name
                        
                        # Создаем бэкап .bak если оригинал существует
                        if target_path.exists():
                            shutil.copy2(target_path, target_path.with_suffix(".py.bak"))
                        
                        # Перезаписываем оригинал кодом из мода
                        target_path.write_text(content, encoding="utf-8")
                        found_mods.append(f"{mod_file.name} -> {original_name}")

        if found_mods:
            report = "\n".join(found_mods)
            messagebox.showinfo("Модинг Успешен", f"Следующие файлы были обновлены:\n\n{report}\n\nОригиналы сохранены с расширением .bak")
        else:
            messagebox.showinfo("Инфо", "Активных модов (заполненных .txt файлов) не обнаружено.")

if __name__ == "__main__":
    ModLauncher()