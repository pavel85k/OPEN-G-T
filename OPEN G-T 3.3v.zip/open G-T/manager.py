import sys
import shutil
from pathlib import Path
import ollama
import traceback

# ====================== CONFIGURATION ======================
BASE_DIR = Path(__file__).parent 
CONFIG_DIR = BASE_DIR / "ai config"
STORAGE_DIR = BASE_DIR / "storing data for a shift"

# Файлы, которые мы будем копировать
FILES_TO_SYNC = [
    "!About you! (required for correct operation).txt",
    "start promt (required for proper operation).txt",
    "chat history (do not touch).txt",
    "behavior (optional).txt",
    "correcting AI errors.txt"
]

MODEL = "deepseek-v3.1:671b-cloud"

# =========================================================

def freeze_on_error(error_msg: str):
    print(f"\n❌ ERROR: {error_msg}")
    input("\n[ЗАМОРОЖЕНО] Нажмите ENTER...")
    sys.exit(1)

def ensure_dirs():
    STORAGE_DIR.mkdir(parents=True, exist_ok=True)
    if not CONFIG_DIR.exists():
        freeze_on_error("Папка 'ai config' не найдена!")

def list_saves():
    """Возвращает список всех сохранений"""
    return [d for d in STORAGE_DIR.iterdir() if d.is_dir()]

def save_session(name: str):
    """Копирует текущие конфиги в папку сохранения"""
    target_path = STORAGE_DIR / name
    target_path.mkdir(parents=True, exist_ok=True)
    
    for filename in FILES_TO_SYNC:
        source = CONFIG_DIR / filename
        if source.exists():
            shutil.copy2(source, target_path / filename)
    print(f"\n✅ Сохранено/Обновлено в папку: {name}")

def load_session(path: Path):
    """Копирует файлы из сохранения в активный конфиг"""
    for file in path.iterdir():
        if file.is_file():
            shutil.copy2(file, CONFIG_DIR / file.name)
    print(f"\n✅ Данные из '{path.name}' успешно загружены в текущую сессию!")

def beta_generate_triad(idea: str):
    """BETA: Генерирует сразу 3 компонента одним процессом"""
    print(f"⏳ [BETA] Генерация тройной системы для: {idea}...")
    
    prompts = {
        "user": f"Create a detailed English User Persona for: {idea}",
        "bot": f"Create a detailed English AI Character for: {idea}",
        "history": f"Write a short opening message in English that sets the scene for this story: {idea}"
    }
    
    results = {}
    for key, p in prompts.items():
        try:
            response = ollama.chat(model=MODEL, messages=[{"role": "system", "content": "You are a Creative Architect."}, {"role": "user", "content": p}])
            results[key] = response['message']['content'].strip()
        except Exception as e:
            results[key] = f"Error generating {key}: {e}"

    # Сохраняем результат
    (CONFIG_DIR / FILES_TO_SYNC[0]).write_text(results["user"], encoding="utf-8")
    (CONFIG_DIR / FILES_TO_SYNC[1]).write_text(results["bot"], encoding="utf-8")
    (CONFIG_DIR / FILES_TO_SYNC[2]).write_text(f"SYSTEM: Scenario started.\n{AI_NAME_PLACEHOLDER}: {results['history']}", encoding="utf-8")
    
    print("\n✨ Триада сгенерирована! (User, Bot, Start Message)")

def main():
    ensure_dirs()
    print("📂 g-t MANAGER: Система сохранений")
    print("-" * 30)
    
    print("1. Сохранить текущую сессию (Save As...)")
    print("2. Загрузить сессию (Load...)")
    print("3. [BETA] Сгенерировать новую триаду (AI Gen)")
    
    cmd = input("\nВыбор: ").strip()

    if cmd == "1":
        name = input("Введите название сохранения: ").strip()
        if name: save_session(name)

    elif cmd == "2":
        saves = list_saves()
        if not saves:
            print("Папка сохранений пуста.")
            return
        
        print("\nДоступные сохранения:")
        for i, path in enumerate(saves, 1):
            print(f"{i}. {path.name}")
        
        choice = input("\nВведите номер или название: ").strip()
        try:
            if choice.isdigit():
                load_session(saves[int(choice)-1])
            else:
                load_session(STORAGE_DIR / choice)
        except:
            print("Ошибка выбора.")

    elif cmd == "3":
        idea = input("Опишите общую задумку (на русском): ").strip()
        if idea: beta_generate_triad(idea)

if __name__ == "__main__":
    try:
        main()
    except Exception:
        freeze_on_error(traceback.format_exc())