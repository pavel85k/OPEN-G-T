import sys
import time
from pathlib import Path
import ollama
import traceback

# ====================== CONFIGURATION ======================
BASE_DIR = Path(__file__).parent 
CONFIG_DIR = BASE_DIR / "ai config"

AI_NAME = "g-tSUPPORT"
USER_NAME = "USER"
MODEL = "deepseek-v3.1:671b-cloud"

# =========================================================

def freeze_on_error(error_msg: str):
    print("\n" + "!" * 60)
    print("SUPPORT AI ERROR:")
    print(error_msg)
    print("!" * 60)
    input("\n[ЗАМОРОЖЕНО] Нажмите ENTER для выхода...")
    sys.exit(1)

def build_support_prompt() -> str:
    """Полная техническая база знаний по проекту open G-T"""
    base_knowledge = (
        "You are the Technical Support for 'open G-T' project. "
        "Your mission: provide expert help regarding this specific project structure and code.\n\n"
        
        "=== PROJECT STRUCTURE ===\n"
        "- Root folder: 'open G-T'\n"
        "- Main scripts: 'chat.py' (Main Bot), 'support ai.py' (Technical Help)\n"
        "- Config folder: 'ai config' (Contains all instructions and logs)\n"
        "- Assets folders: 'icon', 'storing data for a shift'\n\n"
        
        "=== CONFIG FILES (ai config) ===\n"
        "1. '!About you!': Contains information about the User (User Profile).\n"
        "2. 'start promt': Core instructions and role for the AI Bot.\n"
        "3. 'behavior': Optional rules for how the AI speaks.\n"
        "4. 'correcting AI errors': Guidelines for fixing AI mistakes.\n"
        "5. 'chat history (do not touch).txt': Database of conversation history.\n\n"
        
        "=== TECHNICAL RULES ===\n"
        "- All config files should be .txt (but script handles missing extensions).\n"
        "- Encoding: UTF-8.\n"
        "- Model used: deepseek-v3.1:671b-cloud via Ollama API.\n"
        "- Memory: 'chat.py' HAS memory (reads history file). 'support ai.py' has NO memory.\n\n"
        
        "=== SUPPORT STYLE ===\n"
        "- Be direct. No roleplay. No 'I am an AI'. Just technical solutions.\n"
        "- If the user asks about a missing folder, tell them to check the Root path.\n"
        "- If a file is not reading, suggest checking the file name for typos."
    )
    return base_knowledge

def get_support_response(user_input: str):
    system_prompt = build_support_prompt()
    
    messages = [
        {"role": "system", "content": system_prompt},
        {"role": "user", "content": user_input}
    ]
    
    try:
        response = ollama.chat(model=MODEL, messages=messages)
        return response['message']['content'].strip()
    except Exception as e:
        return f"⚠️ Ошибка API: {e}"

def main():
    print(f"🛠 {AI_NAME} (База знаний: open G-T)")
    print(f"🤖 Модель: {MODEL}")
    print("💡 Задавайте вопросы по структуре, папкам или коду проекта.")
    print("-" * 30)

    while True:
        try:
            user_input = input(f"\n{USER_NAME}: ").strip()
            if not user_input:
                continue

            if user_input.lower() in ["exit", "quit", "выход"]:
                break

            print(f"⏳ Анализ запроса...")
            response_text = get_support_response(user_input)
            
            print(f"\n{AI_NAME}:\n{response_text}")
            print("\n" + "-" * 20)

        except KeyboardInterrupt:
            break
        except Exception:
            freeze_on_error(traceback.format_exc())

if __name__ == "__main__":
    try:
        main()
    except Exception:
        freeze_on_error(traceback.format_exc())