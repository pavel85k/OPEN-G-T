import sys
from pathlib import Path
import ollama
import traceback

# ====================== CONFIGURATION ======================
BASE_DIR = Path(__file__).parent 
CONFIG_DIR = BASE_DIR / "ai config"
AI_NAME = "g-tCREATOR"
MODEL = "deepseek-v3.1:671b-cloud"

# =========================================================

def freeze_on_error(error_msg: str):
    print("\n" + "!" * 60)
    print("CREATOR ERROR:")
    print(error_msg)
    print("!" * 60)
    input("\n[FREEZE] Нажмите ENTER для выхода...")
    sys.exit(1)

def load_config(filename: str) -> str:
    # Пробуем найти файл с .txt или без
    for name in [filename, f"{filename}.txt"]:
        file_path = CONFIG_DIR / name
        if file_path.exists():
            return file_path.read_text(encoding="utf-8").strip()
    return ""

def save_config(filename: str, content: str):
    """Автоматически записывает контент в файл"""
    file_path = CONFIG_DIR / filename
    # Если файла нет, добавим .txt
    if not file_path.exists() and not file_path.name.endswith(".txt"):
        file_path = CONFIG_DIR / f"{filename}.txt"
        
    try:
        file_path.write_text(content, encoding="utf-8")
        print(f"✅ Файл успешно обновлен: {file_path.name}")
    except Exception as e:
        print(f"❌ Не удалось сохранить файл: {e}")

def get_creator_response(target_type: str, idea: str):
    current_user = load_config("!About you! (required for correct operation)")
    current_bot = load_config("start promt (required for proper operation)")

    system_prompt = (
        "You are an expert in Prompt Engineering and Character Design.\n"
        "Your task: Create a highly detailed English description for an AI system.\n\n"
        "--- YOUR MISSION ---\n"
        f"The user wants to create/improve a {target_type} based on this idea: '{idea}'.\n"
        "1. If it's a USER PERSONA: Describe the user's background and style.\n"
        "2. If it's a BOT CHARACTER: Define its personality and tone.\n"
        "3. Translate the idea to English and ENHANCE it significantly.\n"
        "4. Output ONLY the final improved text. No conversational filler."
    )
    
    messages = [
        {"role": "system", "content": system_prompt},
        {"role": "user", "content": f"Target: {target_type}. Core Idea: {idea}"}
    ]
    
    try:
        response = ollama.chat(model=MODEL, messages=messages)
        return response['message']['content'].strip()
    except Exception as e:
        return f"⚠️ API Error: {e}"

def main():
    if not CONFIG_DIR.exists():
        freeze_on_error(f"Папка 'ai config' не найдена в {BASE_DIR}")

    print(f"🎭 {AI_NAME}: Автоматический Конструктор")
    print(f"🤖 Модель: {MODEL}")
    print("-" * 40)

    while True:
        try:
            print("\nЧто обновляем?")
            print("1 - Мой профиль (!About you!)")
            print("2 - Характер бота (start promt)")
            
            choice = input("\nВыбор (1 или 2): ").strip()
            if choice not in ['1', '2']:
                continue

            idea = input(f"Опишите идею (на русском): ").strip()
            if not idea:
                continue

            print(f"⏳ Генерируем и сохраняем...")
            
            target_name = "User Persona" if choice == '1' else "Bot Character"
            filename = "!About you! (required for correct operation).txt" if choice == '1' else "start promt (required for proper operation).txt"
            
            improved_text = get_creator_response(target_name, idea)
            
            print("\n" + "="*20 + " НОВЫЙ ПРОМПТ " + "="*20)
            print(improved_text)
            print("="*54)

            # АВТОМАТИЧЕСКАЯ ЗАПИСЬ
            save_config(filename, improved_text)
            print("-" * 40)

        except KeyboardInterrupt:
            print("\n👋 Выход.")
            break
        except Exception:
            freeze_on_error(traceback.format_exc())

if __name__ == "__main__":
    main()